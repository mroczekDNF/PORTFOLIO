#ifndef CASEAR_CLASS_H
#define CASEAR_CLASS_H

class PLAYER_CLASS;

class CAESAR_CLASS{
    private:
        unsigned int sentencedPlayers;
    public:
        void judgeDeathOrLife(PLAYER_CLASS* player, unsigned int playerAttacks);
};
#endif