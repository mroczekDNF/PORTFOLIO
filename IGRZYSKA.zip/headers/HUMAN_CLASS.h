#ifndef HUMAN_CLASS_H
#define HUMAN_CLASS_H

class PLAYER_CLASS;
#include <string>

class HUMAN_CLASS: public virtual PLAYER_CLASS{
    protected:
        unsigned int defenceVal;
        unsigned int getDefence();
    public:
        HUMAN_CLASS():PLAYER_CLASS(), defenceVal(0){};
        HUMAN_CLASS(std::string playerName); 

        unsigned int getAgility();
        unsigned int getDamage();

        void takeDamage(unsigned int dmgVal);
        void printParams();

        void applyWinnerReward();
        void cure();
        void die();
        unsigned int getRemainingHealth();
};
#endif