#ifndef LIST_CLASS_H
#define LIST_CLASS_H

class PLAYER_CLASS;

// wchodza istniejace juz player_class dlatego nie alokujemy nowej pamieci tylko wskaznik
class NODE{
    public:
        PLAYER_CLASS* player;
        NODE* next;
        NODE* prev;
        NODE();
        NODE(PLAYER_CLASS* p1);
};

#endif