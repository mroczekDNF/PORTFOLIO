#ifndef PLAYER_CLASS_H
#define PLAYER_CLASS_H

#include <string>
#include <iostream>

class PLAYER_CLASS{
    protected:
        unsigned int maxHealth;
        unsigned int currHealth;
        unsigned int attackVal;
        unsigned int agilityVal;
        unsigned int tmp;
        std::string name;
        virtual void die();
    public:
        int killedByCaesar;
//      wątpliwa użytecznosc

        int used;
        PLAYER_CLASS();

        std::string getName();
        void setName(std::string name);
        unsigned int getNumberHealth();
        unsigned int getMaxHealth();

        virtual unsigned int getRemainingHealth();
        virtual void applyWinnerReward()=0;
        virtual void cure();
        virtual unsigned int getAgility()=0;
        virtual void printParams()=0;
        virtual unsigned int getDamage() =0;
        virtual void takeDamage(unsigned int dmgPoints) =0;

        friend class CAESAR_CLASS;
        friend class ARENA_CLASS;
        friend class SQUAD_CLASS;
};    
#endif
