#ifndef BERSERKER_CLASS_H
#define BERSERKER_CLASS_H

#include "HUMAN_CLASS.h"
#include "BEAST_CLASS.h"

#include <string>

class BERSERKER_CLASS: public HUMAN_CLASS, public BEAST_CLASS{
    private:
        int isBeast;
        std::string nameHuman;
        std::string nameBeast;

    public:
        BERSERKER_CLASS():HUMAN_CLASS(){};
        BERSERKER_CLASS(std::string humanName, std::string beastName);
        unsigned int getRemainingHealth();

        unsigned int getAgility();
        unsigned int getDamage();
        
        void printParams();

        void takeDamage(unsigned int dmgVal);

        void applyWinnerReward();
        void cure();

        void die();
};
#endif