#ifndef BEAST_CLASS_H
#define BEAST_CLASS_H

#include <string>
#include "PLAYER_CLASS.h"

class BEAST_CLASS: public virtual PLAYER_CLASS{
    private:
        std::string beastName;
    public:

        BEAST_CLASS();

        BEAST_CLASS(std::string nameBeast);

        unsigned int getDamage();

        void takeDamage(unsigned int dmgVal);

        void printParams();

        unsigned int getAgility();

        void applyWinnerReward();
        void cure();
        void die();

        unsigned int getRemainingHealth();
};   
#endif