#ifndef SQUAD_CLASS_H
#define SQUAD_CLASS_H

#include <string>
#include "PLAYER_CLASS.h"
#include "NODE_CLASS.h"

class SQUAD_CLASS: public PLAYER_CLASS{
    protected:
        std::string squadName;
        unsigned int numMembers;
        int emptySquad;
        bool checkIdentity(PLAYER_CLASS* x);
        void removeMember(NODE* player);
        void removeSquad();
        void sortPlayers();
        PLAYER_CLASS* findMin();
        bool relation(PLAYER_CLASS* x, PLAYER_CLASS* y);
        unsigned int remainHealth(); 
        void applyWinnerReward();
        void cure();
        void die();

    public:
        NODE* first;

        SQUAD_CLASS();
        SQUAD_CLASS(std::string name);

        void addPlayer(PLAYER_CLASS* newPlayer);
        unsigned int getAgility();
        unsigned int getDamage();
        void takeDamage(unsigned int dmgVal);
        void printParams();
        unsigned int getRemainingHealth();
        unsigned int countMembers();
        ~SQUAD_CLASS();
};

#endif