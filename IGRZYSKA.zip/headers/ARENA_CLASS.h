#ifndef ARENA_CLASS_H
#define ARENA_CLASS_H

#include "CAESAR_CLASS.h"
class PLAYER_CLASS;

class ARENA_CLASS{
    private:
        CAESAR_CLASS Caesar;
    public:
        ARENA_CLASS(CAESAR_CLASS* pointerCaesar){
            Caesar = *pointerCaesar;
        }
        void fight(PLAYER_CLASS* playerOne, PLAYER_CLASS* playerTwo);

    private:
        void startFight(PLAYER_CLASS* playerOne, PLAYER_CLASS* playerTwo, unsigned int& playerAttacks);

        void checkWinner(PLAYER_CLASS* player);
};

#endif

