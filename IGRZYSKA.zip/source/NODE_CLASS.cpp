#include "../headers/NODE_CLASS.h"

NODE::NODE(): player(nullptr), next(nullptr), prev(nullptr){};
NODE::NODE(PLAYER_CLASS* newPlayer): player(newPlayer){}
