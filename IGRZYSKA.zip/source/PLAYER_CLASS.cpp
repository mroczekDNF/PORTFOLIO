#include "../headers/PLAYER_CLASS.h"

PLAYER_CLASS::PLAYER_CLASS(): used(0), maxHealth(0), currHealth(0), attackVal(0), agilityVal(0),
    killedByCaesar(0){};
    
std::string PLAYER_CLASS::getName(){
    return name;
}
unsigned int PLAYER_CLASS::getNumberHealth(){
    return currHealth;
}
unsigned int PLAYER_CLASS::getMaxHealth(){
    return maxHealth;
}
unsigned int PLAYER_CLASS::getAgility(){
    return agilityVal;
}
unsigned int PLAYER_CLASS::getRemainingHealth(){
    return (currHealth * 100)/maxHealth;
}
void PLAYER_CLASS::cure(){
    currHealth = maxHealth;
}

void PLAYER_CLASS::printParams(){
    std::cout << name << ":";
    if(currHealth > 0){
        std::cout << maxHealth << ":" << currHealth << ":"
        << getRemainingHealth() << "%:" << attackVal << ":" << agilityVal;
    }else{
        std::cout << "R.I.P." << std::endl;
    }
}
void PLAYER_CLASS::die(){
    currHealth = 0;
}
void PLAYER_CLASS::applyWinnerReward(){
    attackVal += 2;
    agilityVal += 2;
}
