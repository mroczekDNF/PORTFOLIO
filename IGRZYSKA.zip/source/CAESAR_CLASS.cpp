#include "../headers/CAESAR_CLASS.h"
#include "../headers/PLAYER_CLASS.h"

void CAESAR_CLASS::judgeDeathOrLife(PLAYER_CLASS* player, unsigned int playerAttacks){
    if(player->getRemainingHealth() <= 0) return;
    
    sentencedPlayers++;    
    if(playerAttacks % 2 == 0){
        if(sentencedPlayers % 3 == 0){
            player->killedByCaesar = 1;
            player->die();
        }
        player->printParams();
    }
}