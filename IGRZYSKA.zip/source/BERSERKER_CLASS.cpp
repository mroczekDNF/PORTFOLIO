#include "../headers/BERSERKER_CLASS.h"

BERSERKER_CLASS::BERSERKER_CLASS():HUMAN_CLASS::PLAYER_CLASS(){};
BERSERKER_CLASS::BERSERKER_CLASS(std::string humanName, std::string beastName){
    maxHealth = 200;
    currHealth = 200;
    attackVal = 35;
    agilityVal = 5;
    defenceVal = 15;

    name = humanName;

    nameHuman = humanName;
    nameBeast = beastName;
}
unsigned int BERSERKER_CLASS::getRemainingHealth(){
    return HUMAN_CLASS::getRemainingHealth();
}


unsigned int BERSERKER_CLASS::getAgility(){
    if(getRemainingHealth() >= 25 || getRemainingHealth() == 0 ){
        name = nameHuman;
        return HUMAN_CLASS::getAgility();
    }else{
        name = nameBeast;
        return BEAST_CLASS::getAgility();
    }
}
unsigned int BERSERKER_CLASS::getDamage(){
    if(getRemainingHealth() >= 25 || getRemainingHealth() == 0){
        name = nameHuman;
        return HUMAN_CLASS::getDamage();
    }else{
        name = nameBeast;
        return BEAST_CLASS::getDamage();
    }
}
void BERSERKER_CLASS::printParams(){
    if(getRemainingHealth() >= 25 || getRemainingHealth() == 0){
        name = nameHuman;
        HUMAN_CLASS::printParams();
    }else{
        name = nameBeast;
        BEAST_CLASS::printParams();
    }
}
void BERSERKER_CLASS::takeDamage(unsigned int dmgVal){
    if(getRemainingHealth() >= 25 || getRemainingHealth() == 0){
        name = HUMAN_CLASS::name;
        HUMAN_CLASS::takeDamage(dmgVal);
    }else{
        name = BEAST_CLASS::name;
        BEAST_CLASS::takeDamage(dmgVal);
    }
}
void BERSERKER_CLASS::applyWinnerReward(){
    if(getRemainingHealth() >= 25 || getRemainingHealth() == 0){
        name = HUMAN_CLASS::name;
        HUMAN_CLASS::applyWinnerReward();
    }else{
        name = BEAST_CLASS::name;
        BEAST_CLASS::applyWinnerReward();
    }
}
void BERSERKER_CLASS::cure(){
    if(getRemainingHealth() >= 25 || getRemainingHealth() == 0){
        name = HUMAN_CLASS::name;
        HUMAN_CLASS::cure();
    }else{
        name = BEAST_CLASS::name;
        BEAST_CLASS::cure();
    }
}
void BERSERKER_CLASS::die(){
    if(getRemainingHealth() >= 25 || getRemainingHealth() == 0){
        name = HUMAN_CLASS::name;
        HUMAN_CLASS::die();
    }else{
        name = BEAST_CLASS::name;
        BEAST_CLASS::die();
    }
}