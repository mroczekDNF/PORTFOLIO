#include "../headers/ARENA_CLASS.h"
#include "../headers/CAESAR_CLASS.h"
#include "../headers/PLAYER_CLASS.h"

void ARENA_CLASS::fight(PLAYER_CLASS* p1, PLAYER_CLASS* p2){    
    // ilosc atakow musi byc jako zmienna w klasie cezara i bedzie potrzebne to do osadu cezara
    PLAYER_CLASS* playerOne = p1;
    PLAYER_CLASS* playerTwo = p2;

    if(playerOne->getRemainingHealth() == 0 || playerTwo->getRemainingHealth() == 0) return;

    if(playerOne->getAgility() < playerTwo->getAgility()){
        playerOne = p2;
        playerTwo = p1;
    }
    unsigned int playerAttacks = 0;

    playerOne->printParams();
    playerTwo->printParams();

    startFight(playerOne, playerTwo, playerAttacks);
    
    Caesar.judgeDeathOrLife(playerOne, playerAttacks);
    Caesar.judgeDeathOrLife(playerTwo, playerAttacks);

    checkWinner(playerOne);
    checkWinner(playerTwo);

    playerOne->printParams();
    playerTwo->printParams();
}

void ARENA_CLASS::startFight(PLAYER_CLASS* playerOne, PLAYER_CLASS* playerTwo, unsigned int& playerAttacks){   
    while(playerOne->getRemainingHealth() >= 10 && playerAttacks < 40){
        playerTwo->takeDamage(playerOne->getDamage());
        playerTwo->printParams();

        playerAttacks++;

        if(playerTwo->getRemainingHealth() < 10 || playerAttacks >= 40) break;

        playerOne->takeDamage(playerTwo->getDamage());
        playerOne->printParams();
        
        playerAttacks++;
    }

    if(playerOne->getRemainingHealth() <= 0) playerOne->die();
    if(playerTwo->getRemainingHealth() <= 0) playerTwo->die();
}

void ARENA_CLASS::checkWinner(PLAYER_CLASS* player){
    if(player->getRemainingHealth() > 0){
        player->applyWinnerReward();
        player->cure();
    }
}