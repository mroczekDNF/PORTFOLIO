#include "../headers/BEAST_CLASS.h"

BEAST_CLASS::BEAST_CLASS():PLAYER_CLASS(){};
BEAST_CLASS::BEAST_CLASS(std::string nameBeast):PLAYER_CLASS(){
    beastName = nameBeast;
    name = nameBeast;
    maxHealth = 150;
    currHealth = 150;
    attackVal = 40;
    agilityVal = 20;
};
unsigned int BEAST_CLASS::getRemainingHealth(){
    return PLAYER_CLASS::getRemainingHealth();
}
unsigned int BEAST_CLASS::getAgility(){
    return PLAYER_CLASS::getAgility();
}
void BEAST_CLASS::die(){
    PLAYER_CLASS::die();
}

void BEAST_CLASS::cure(){
    PLAYER_CLASS::cure();
}

void BEAST_CLASS::applyWinnerReward(){
    PLAYER_CLASS::applyWinnerReward();
}
unsigned int BEAST_CLASS::getDamage(){
    if(getRemainingHealth() < 25) return 2*attackVal;
    return attackVal;
}
void BEAST_CLASS::takeDamage(unsigned int dmgVal){

    int trueDmg = dmgVal - getAgility()/2;

    if(trueDmg < 0) trueDmg = 0;

    int x = getNumberHealth() - trueDmg;

    if(x <= 0){
      die();
    };

    currHealth = x;
}
void BEAST_CLASS::printParams(){
    std::cout << name << ":";
    if(currHealth > 0){
        std::cout << maxHealth << ":" << currHealth << ":"
        << getRemainingHealth() << "%:" << getDamage() << ":" << getAgility() << std::endl;
    }else{
        std::cout << "R.I.P." << std::endl;
    }
}