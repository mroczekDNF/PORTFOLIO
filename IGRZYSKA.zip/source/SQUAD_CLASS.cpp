#include "../headers/SQUAD_CLASS.h"
#include "../headers/PLAYER_CLASS.h"
#include "../headers/NODE_CLASS.h"

SQUAD_CLASS::SQUAD_CLASS(): numMembers(0){
            emptySquad = 0;
            first = nullptr;
        };
    
SQUAD_CLASS::SQUAD_CLASS(std::string name): squadName(name), numMembers(0){
    emptySquad = 0;
    first = nullptr;
}

SQUAD_CLASS::~SQUAD_CLASS(){
    NODE* curr = first->next;

    if(first->next == nullptr){
        delete first;
        first = nullptr;
        return;
    }
    while(curr != nullptr){
        delete curr->prev;
        curr = curr->next;
    }
}

unsigned int SQUAD_CLASS::countMembers(){
    NODE* curr = first;

    if(curr == NULL) return 0;

    unsigned int i = 0;
    while(curr->player != NULL){
        if(curr->player->getRemainingHealth() > 0) i++;
        curr = curr->next;
    }
    numMembers = i;
    if(i == 0) emptySquad = 1;
    return i;
}

void SQUAD_CLASS::die(){
    if(killedByCaesar){
        NODE* current = first;
    
        while ( current != NULL ) {
            current->player->die();
            current = current->next;
        }
        first  == NULL;
        emptySquad = 1;
    }else{
        PLAYER_CLASS::die();
    }

}

void SQUAD_CLASS::cure(){
    NODE* curr = first;
    while(curr != NULL){
        if(curr->player->getRemainingHealth() > 0){
            curr->player->cure();
        }
        curr = curr->next;
    }
}

void SQUAD_CLASS::applyWinnerReward(){
    NODE* curr = first;

    while(curr != NULL){
        if(curr->player->getRemainingHealth() > 0){
            curr->player->applyWinnerReward();
        }
        curr = curr->next;
    }
};

unsigned int SQUAD_CLASS::getRemainingHealth(){
    if(emptySquad) return 0;

    return remainHealth();
};

void SQUAD_CLASS::addPlayer(PLAYER_CLASS* newPlayer){
    if(newPlayer->getRemainingHealth() > 0){

        if(first == NULL){
            first = new NODE(newPlayer);
            numMembers++;
        }else{
            if(checkIdentity(newPlayer)){
                
                NODE* newMember = new NODE(newPlayer);

                newMember->next = first;

                first->prev = newMember;
                first = newMember;
                numMembers++;    
            }
        }
    }
}

unsigned int SQUAD_CLASS::getAgility(){
    
    if(first == NULL) return 0;

    NODE* currObj = first;

    unsigned int minAgility = currObj->player->getAgility();


    while(currObj->next != NULL){

        currObj = currObj->next;
        unsigned int currAgility = currObj->player->getAgility();
        if(currAgility < minAgility && currObj->player->getRemainingHealth() > 0){
            minAgility = currAgility;
        }
    }
    return minAgility;
}

unsigned int SQUAD_CLASS::getDamage(){

    if(first == NULL) return 0;

    NODE* currObj = first;
    unsigned int sum = 0;

    while(currObj != NULL && currObj->player->getRemainingHealth() > 0){
        
        sum += currObj->player->getDamage();
        currObj = currObj->next;
    }
    return sum;
}

void SQUAD_CLASS::takeDamage(unsigned int dmgVal){
    if(first == NULL) return;

    numMembers = countMembers();
    dmgVal = dmgVal / numMembers;

    NODE* current = first;

    while(current != NULL ){
            current->player->takeDamage(dmgVal);
        if (current->player->getRemainingHealth() <= 0){
                current->player->die();
                NODE* next = current->next;
                NODE* prev = current->prev;

                if (current == first){
                    if ( next == NULL ){
                        delete first;
                        first = NULL;
                        current = NULL;
                    }else {
                        first = next;
                        delete first;
                        next->prev = NULL;
                        current = current->next;
                    }
                }
                else {
                    if ( next == NULL ){
                        prev->next = NULL;
                        delete current;
                        current = NULL;
                    }else {
                        current = current->next;
                        delete current;
                        next->prev = prev;
                        prev->next = next;
                    }
                }

            }else{
                current = current->next;
            }
    }
    numMembers = countMembers();
}

bool SQUAD_CLASS::checkIdentity(PLAYER_CLASS* x){
    NODE* curr = first;
    while(curr != NULL){
        if(curr->player == x) return false;
        curr = curr->next;
    }
    return true;
}

bool SQUAD_CLASS::relation(PLAYER_CLASS* x, PLAYER_CLASS* y){

    std::string nameX = x->getName();
    std::string nameY = y->getName();

    if(nameX > nameY){
        return true;
    }else if(nameX == nameY){
        unsigned int tmpX = x->getMaxHealth();
        unsigned int tmpY = y->getMaxHealth();

        if(tmpX > tmpY){
            return true;
        }else if (tmpX == tmpY){
            tmpX = x->getNumberHealth();
            tmpY = y->getNumberHealth();
            if(tmpX > tmpY){
                return true;
            }else{
                if(tmpX == tmpY){
                    tmpX = x->getDamage();
                    tmpY = y->getDamage();
                    if(tmpX > tmpY){
                        return true;
                    }else{
                        if(tmpX == tmpY){
                            tmpX = x->getAgility();
                            tmpY = y->getAgility();
                            if(tmpX > tmpY){
                                return true;
                            };
                        }
                    }
                }
            }
        }
    }
    return false;
}

unsigned int SQUAD_CLASS::remainHealth(){
    NODE* curr = first;

    if(countMembers() == 0 || first == nullptr) return 0;

    unsigned int currSumHealth = 0;
    unsigned int maxSumHealth = 0;

    unsigned int maxRemainHealth = 0;

    while(curr != NULL){
        if(curr->player->getRemainingHealth() > 0){    
            if(curr->player->getRemainingHealth() > maxRemainHealth){
                maxRemainHealth = curr->player->getRemainingHealth();
            }
        }
        curr = curr->next;
    }
    return maxRemainHealth;
}

PLAYER_CLASS* SQUAD_CLASS::findMin(){

    PLAYER_CLASS* min;
    NODE* curr = first;

    while(curr != NULL){
        if(curr->player->used == 0 && curr->player->getRemainingHealth() > 0){
            min = curr->player;
            break;
        }
        curr = curr -> next;
    }
    curr = first;
    while(curr != NULL){

        if(curr->player->used == 0 && curr->player->getRemainingHealth() > 0){
            if(relation(min, curr->player)){
                min = curr->player;
            }
        }
        curr = curr->next;
    }
    return min;
}   

void SQUAD_CLASS::printParams(){

    if( first == nullptr || emptySquad == 1){
        std::cout << squadName << ":" << "nemo" << std::endl;
        return;
    }

    NODE* curr = first;

    while(curr != NULL){

        if(curr->player->getRemainingHealth() > 0) break;
        curr = curr->next;
    }

    if(curr == NULL) {
        emptySquad = 1;
        std::cout << squadName << ":" << "nemo" << std::endl;
        return;
    }else{
        std::cout << squadName << ":" << numMembers << ":" <<
        getRemainingHealth() << "%:" << getDamage() << ":" << getAgility() << std::endl; 

        NODE* iter = first;
        while(iter != NULL){
        PLAYER_CLASS* min = findMin();
        NODE* curr = first;
        
        while(curr != NULL){
            if(curr->player == min  && curr->player->used == 0 && curr->player->getRemainingHealth() > 0){
                curr->player->used = 1;
                curr->player->printParams();
                break;
            }
            curr = curr->next;
        }
        iter = iter->next;
    }

    iter = first;

    while(iter != NULL){
        if(iter->player->getRemainingHealth() > 0){
            iter->player->used = 0;
        }
        iter = iter->next;
    }
    }
}