#include "../headers/HUMAN_CLASS.h"
#include "../headers/PLAYER_CLASS.h"

HUMAN_CLASS::HUMAN_CLASS(std::string playerName): PLAYER_CLASS(){
    name = playerName;
    maxHealth = 200;
    currHealth = 200;
    attackVal = 30;
    agilityVal = 10;
    defenceVal = 10;
}

HUMAN_CLASS::HUMAN_CLASS():PLAYER_CLASS(), defenceVal(0){};


unsigned int HUMAN_CLASS::getDefence(){
    return defenceVal;
}


unsigned int HUMAN_CLASS::getRemainingHealth(){
    return PLAYER_CLASS::getRemainingHealth();
}

void HUMAN_CLASS::die(){
    PLAYER_CLASS::die();
}

void HUMAN_CLASS::cure(){
    PLAYER_CLASS::cure();
}

void HUMAN_CLASS::applyWinnerReward(){
    PLAYER_CLASS::applyWinnerReward();
}

unsigned int HUMAN_CLASS::getAgility(){
    return PLAYER_CLASS::getAgility();
}
unsigned int HUMAN_CLASS::getDamage(){
    return attackVal;
}
void HUMAN_CLASS::takeDamage(unsigned int dmgVal){

    int trueDmg = dmgVal - ( getDefence() + getAgility());

    if(trueDmg < 0) trueDmg = 0;

    int x = getNumberHealth() - trueDmg;

    if(x <= 0){
        die();
    };

    currHealth = x;
}
void HUMAN_CLASS::printParams(){
    std::cout << name << ":";

    if(currHealth > 0){
        std::cout << maxHealth << ":" << currHealth << ":"
        << getRemainingHealth() << "%:" << getDamage() << ":" << getAgility() << ":" << defenceVal << std::endl;
    }else{
        std::cout << "R.I.P." << std::endl;
    }
}