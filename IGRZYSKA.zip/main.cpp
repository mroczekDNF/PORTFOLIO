#include "headers/ALL_HEADERS.h"

int main(){
    CAESAR_CLASS Cezar;
    ARENA_CLASS Arena(&Cezar);
    BERSERKER_CLASS Berserker1("BerserkerHuman1", "BerserkerBeast1");
    BERSERKER_CLASS Berserker2("BerserkerHuman2", "BerserkerBeast2");
    int i = 100;

    while (i > 0) {
        Berserker1.applyWinnerReward();
        i -= 1;
    }
    i = 50;
    while (i > 0) {
        Berserker2.applyWinnerReward();
        i -= 1;
    }

    HUMAN_CLASS Warrior1("Warrior1");
    HUMAN_CLASS Warrior2("Warrior2");
    HUMAN_CLASS Warrior3("Warrior3");
    HUMAN_CLASS Warrior4("Warrior4");
    HUMAN_CLASS Warrior5("Warrior5");
    HUMAN_CLASS Warrior6("Warrior6");
    HUMAN_CLASS Warrior7("Warrior7");
    HUMAN_CLASS Warrior8("Warrior8");

    SQUAD_CLASS GigaSquad1("GigaSquad1");

    SQUAD_CLASS MediumSquad1("MediumSquad1");

    SQUAD_CLASS SmallSquad1("SmallSquad1");
    SQUAD_CLASS SmallSquad2("SmallSquad2");

    SmallSquad1.addPlayer(&Warrior1);
    SmallSquad1.addPlayer(&Warrior2);
    SmallSquad2.addPlayer(&Warrior3);
    SmallSquad2.addPlayer(&Warrior4);

    MediumSquad1.addPlayer(&SmallSquad1);
    MediumSquad1.addPlayer(&SmallSquad2);

    GigaSquad1.addPlayer(&MediumSquad1);
    GigaSquad1.addPlayer(&Berserker2);

    Arena.fight(&GigaSquad1, &Berserker1);

    return 0;
}